def somme(a, b):
    return a+b # ← compléter ici


# tests

assert somme(10, 32) == 42
assert somme(100, 7) == 107

