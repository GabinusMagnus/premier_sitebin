# UN SEUL PARAMETRE #

# Les entiers de 0 (inclus) à 11 (exclu)
liste_1 = list(range(11))

# Les entiers de 0 (inclus) à 20 (exclu)
liste_2 = list(range(20))

# Les entiers de 0 (inclus) à 20 (inclus)
liste_3 = list(range(21))

# DEUX PARAMETRES #

# Les entiers de 3 (inclus) à 10 (exclu)
liste_4 = list(range(3, 10))

# Les entiers de 12 (inclus) à 20 (inclus)
liste_5 = list(range(12, 21))

# Les entiers de -10 (inclus) à 1 (exclu)
liste_6 = list(range(-10, 1))

# Les entiers de -10 (inclus) à 1 (inclus)
liste_7 = list(range(-10, 2))

# TROIS PARAMETRES #

# Les entiers de 20 (inclus) à 0 (exclu)
liste_8 = list(range(21, 0, -1))  

# Les entiers de 500 (inclus) à 200 (exclu)
liste_9 = list(range(500, 200, -1))

# Les entiers de 10 (inclus) à -10 (exclu)
liste_10 = list(range(10, -10, -1))

# Les entiers de 25 (inclus) à -25 (inclus)
liste_11 = list(range(25, -26, -1))

# Les pairs de 1 (inclus) à 100 (exclu)
liste_12 = list(range(0, 100, 2))

# Les multiples de 3 de 0 (inclus) à 301 (exclu)
liste_13 = list(range(0, 301, -3))

# Les multiples de 7 de 0 (inclus) à 994 (inclus)
liste_14 = list(range(0, 995, 7))

# Les pairs de -100 (inclus) à 100 (exclu)
liste_15 = list(range(-100, 100, 2))

# Les multiples de 3 de 300 (inclus) à 102 (exclu)
liste_16 = list(range(300, 102, -3))

# Les multiples de 13 de 3445 (inclus) à -559 (inclus)
liste_17 = list(range(3445, -560, -13))

